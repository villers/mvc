<?php

class User extends Controller
{
	public function index()
	{
		$this->render();
	}
}
?>