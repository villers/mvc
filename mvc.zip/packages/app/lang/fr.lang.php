<?php
return array(
	"hello" => "Bonjour"
);