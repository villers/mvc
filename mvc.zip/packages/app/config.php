<?php 
return array(
	/* Sql Connection Via PDO */
	"PDO_USE" => true,
	//"PDO_PREFIX" => "db_", 
	"PDO_DRIVER" => "mysql", 
	"PDO_HOST" => "127.0.0.1", 
	//"PDO_PORT" => "", 
	"PDO_DATABASE" => "mvc", 
	"PDO_USER" => "root", 
	"PDO_PASSWORD" => "",

	/* Cache */
	"CACHE_TWIG" => false
);
?>