mvc
===

personal mvc

* Editer /package/app/config.php\n
* Ajouter les droits d'écriture au dossier /package/app/tmp


contact: villersm@hotmail.com