<?php

class Home extends Controller
{
	public function index()
	{
		$this->render();
	}

	public function teste()
	{
		$this->render();
	}
}
?>