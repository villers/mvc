<?php

class Test
{
	public function __construct()
	{
		echo "lol";
	}
}
?>